<?php

/*
 * Copyright (C) 2013 peter
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

include_once 'db_connect.php';
include_once 'psl-config.php';


// function check_password_strength($password)
// {
//    $data = array("123456","123456789","qwerty","12345678","111111","1234567890","1234567","password","123123","987654321","qwertyuiop","mynoob","123321","666666","18atcskd2w","7777777","1q2w3e4r","654321","555555","3rjs1la7qe","google","1q2w3e4r5t","123qwe","zxcvbnm","1q2w3e");
//    $ans=1000000;
//    $str;
//    for($i = 0;$i<25;$i++)
//    {
//      $ans = min($ans,levenshtein($data[$i],$password));
//      $str = $data[$i];
//    }
//    return $ans;
// }

function does_exist($username,$mysqli)
{
    $prep_stmt = "SELECT id FROM members WHERE username = ? LIMIT 1";
    $stmt = $mysqli->prepare($prep_stmt);

    if ($stmt) {
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows == 1) {
            // A user with this email address already exists
            // echo "hellllllo";
            return true;
        }
    } else {
        return false;
    }

}

function find_new_name($username,$mysqli)
{
   $dummy = $username;
   while(does_exist($dummy,$mysqli)==true)
   {
      $dummy = $username;
      $num = rand(1,100);
      $dummy = $dummy.$num;
   }
   return $dummy;
}

$error_msg = "";

if (isset($_POST['username'], $_POST['email'], $_POST['p'],$_POST['q'])) {
    // Sanitize and validate the data passed in
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $email = filter_var($email, FILTER_VALIDATE_EMAIL);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Not a valid email
        $error_msg .= '<p class="error">The email address you entered is not valid</p>';
    }

    $password = filter_input(INPUT_POST, 'p', FILTER_SANITIZE_STRING);
    $answer = filter_input(INPUT_POST, 'q', FILTER_SANITIZE_STRING);
    // echo $password;
    // echo $answer;
    if (strlen($password) != 128) {
        // The hashed pwd should be 128 characters long.
        // If it's not, something really odd has happened
        $error_msg .= '<p class="error">Invalid password configuration.</p>';
    }
    // $answer = filter_input(INPUT_POST, 'answer',FILTER_SANITIZE_STRING);
    $question = filter_input(INPUT_POST,'question',FILTER_SANITIZE_STRING);
    // echo $answer;
    // var_dump( $mysqli);

    // Username validity and password validity have been checked client side.
    // This should should be adequate as nobody gains any advantage from
    // breaking these rules.
    //
    // echo find_new_name("1",$mysqli);
    // echo check_password_strength("1234");
    // echo $password;


    $prep_stmt = "SELECT id FROM members WHERE email = ? LIMIT 1";
    $stmt = $mysqli->prepare($prep_stmt);

    if ($stmt) {
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows == 1) {
            // A user with this email address already exists
            $error_msg .= '<p class="error">A user with this email address already exists.</p>';
        }
    } else {
        $error_msg .= '<p class="error">Database error</p>';
    }

    $prep_stmt = "SELECT id FROM members WHERE username = ? LIMIT 1";
    $stmt = $mysqli->prepare($prep_stmt);

    if ($stmt) {
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows == 1) {
            // A user with this email address already exists
            $new_user_name = find_new_name($username,$mysqli);
            $error_msg .= '<p class="error">A user with this username already exists. Try '. $new_user_name .' </p>';
        }
    } else {
        $error_msg .= '<p class="error">Database error</p>';
    }

    // TODO:
    // We'll also have to account for the situation where the user doesn't have
    // rights to do registration, by checking what type of user is attempting to
    // perform the operation.

    if (empty($error_msg)) {
        // Create a random salt
        $random_salt = hash('sha512', uniqid(openssl_random_pseudo_bytes(16), TRUE));

        // Create salted password
        $password = hash('sha512', $password . $random_salt);

        $random  = hash('sha512', uniqid(openssl_random_pseudo_bytes(16), TRUE));
        // $answer = hash('sha512', $answer . $random_salt);

        // Insert the new user into the database
        if ($insert_stmt = $mysqli->prepare("INSERT INTO members (username, email, password, salt) VALUES (?, ?, ?, ?)")) {
            $insert_stmt->bind_param('ssss', $username, $email, $password, $random_salt);
            // Execute the prepared query.
            if (! $insert_stmt->execute()) {
                header('Location: ../error.php?err=Registration failure: INSERT');
                exit();
            }
        }
        if ($insert_stmt = $mysqli->prepare("INSERT INTO security (username, question, answer, answer_salt) VALUES (?, ?, ?, ?)")) {
            $insert_stmt->bind_param('ssss', $username, $question, $answer, $random);
            // Execute the prepared query.
            if (! $insert_stmt->execute()) {
                header('Location: ../error.php?err=Registration failure: INSERT');
                exit();
            }
        }
        // if ($insert_stmt = $mysqli->prepare("INSERT INTO security_qa (question,answer,username) VALUES (?, ?, ?)")) {
        //     $insert_stmt->bind_param('sss', $question, $answer,$username);
        //     // Execute the prepared query.
        //     if (! $insert_stmt->execute()) {
        //         header('Location: ../error.php?err=Registration failure: INSERT');
        //         exit();
        //     }
        // }
        header('Location: ./register_success.php');
        exit();
    }
}
